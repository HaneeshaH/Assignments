from datetime import datetime

class App_Logger:
    def __init__(self):
        pass

    def log(self, file_object, log_message):
        self.now = datetime.now()
        self.date = self.now.date()
        self.current_time = self.now.strftime("%H:%M:%S")
        record = {
            'Date': str(self.date),
            'Time': self.current_time,
            'Message': log_message,
        }
        file_object.insert_one(record) # inserting current system Date ,Time and Log message