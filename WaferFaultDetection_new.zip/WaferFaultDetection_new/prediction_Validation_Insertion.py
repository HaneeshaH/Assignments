from datetime import datetime
from Prediction_Raw_Data_Validation.predictionDataValidation import Prediction_Data_validation
from DataTypeValidation_Insertion_Prediction.DataTypeValidationPrediction import dBOperation
from DataTransformation_Prediction.DataTransformationPrediction import dataTransformPredict
from application_logging import logger

class pred_validation:
    def __init__(self,path):
        self.raw_data = Prediction_Data_validation(path)
        self.dataTransform = dataTransformPredict()
        self.dBOperation = dBOperation()
        #self.file_object = open("Prediction_Logs/Prediction_Log.txt", 'a+')
        self.log_writer = logger.App_Logger()

    def prediction_validation(self):

        try:

            conn = self.dBOperation.dataBaseConnection()
            db = conn.get_database('Prediction_Logs')  # opening Training_Logs database
            log_table = db.Prediction_Log  # opening Training_Main_Log collection
            self.log_writer.log(log_table,'Start of Validation on files for prediction!!')
            #extracting values from prediction schema
            LengthOfDateStampInFile,LengthOfTimeStampInFile,column_names,noofcolumns = self.raw_data.valuesFromSchema()
            #getting the regex defined to validate filename
            regex = self.raw_data.manualRegexCreation()
            #validating filename of prediction files
            self.raw_data.validationFileNameRaw(regex,LengthOfDateStampInFile,LengthOfTimeStampInFile)
            #validating column length in the file
            self.raw_data.validateColumnLength(noofcolumns)
            #validating if any column has all values missing
            self.raw_data.validateMissingValuesInWholeColumn()
            self.log_writer.log(log_table,"Raw Data Validation Complete!!")

            self.log_writer.log(log_table,("Starting Data Transforamtion!!"))
            #replacing blanks in the csv file with "Null" values to insert in table
            self.dataTransform.replaceMissingWithNull()

            self.log_writer.log(log_table,"DataTransformation Completed!!!")
            # inserting good data csv in to InputFile table
            self.dBOperation.insertIntoTableGoodData()
            self.log_writer.log(log_table,"Insertion in Table completed!!!")
            self.log_writer.log(log_table,"Deleting Good Data Folder!!!")
            #Delete the good data folder after loading files in table
            self.raw_data.deleteExistingGoodDataTrainingFolder()
            self.log_writer.log(log_table,"Good_Data folder deleted!!!")
            self.log_writer.log(log_table,"Moving bad files to Archive and deleting Bad_Data folder!!!")
            #Move the bad files to archive folder
            self.raw_data.moveBadFilesToArchiveBad()
            self.log_writer.log(log_table,"Bad files moved to archive!! Bad folder Deleted!!")
            self.log_writer.log(log_table,"Validation Operation completed!!")
            self.log_writer.log(log_table,"Extracting csv file from table")
            #export data in table to csvfile'''
            self.dBOperation.selectingDatafromtableintocsv()

        except Exception as e:
            raise e









