import shutil
import sqlite3
from datetime import datetime
from os import listdir
import os
import csv
from pymongo import MongoClient
from application_logging.logger import App_Logger
import pandas as pd


class dBOperation:
    """
      This class shall be used for handling all the SQL operations.

      Written By: iNeuron Intelligence
      Version: 1.0
      Revisions: None

      """
    def __init__(self):
        #self.path = 'Training_Database/'
        self.badFilePath = "Training_Raw_files_validated/Bad_Raw"
        self.goodFilePath = "Training_Raw_files_validated/Good_Raw"
        self.df=pd.DataFrame()
        self.logger = App_Logger()


    def dataBaseConnection(self):

        """
                Method Name: dataBaseConnection
                Description: This method creates connection with the mongodb atlas cluster
                Output: Connection to the Cluster
                On Failure: Raise ConnectionError

                 Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                """
        try:
            conn = MongoClient("mongodb+srv://han:test123@hancluster.ac08d.mongodb.net/wafer_train?retryWrites=true&w=majority")

        except Exception as e:
            raise e
        return conn


    def insertIntoTableGoodData(self):

        """
                               Method Name: insertIntoTableGoodData
                               Description: This method inserts the Good data files from the Good_Raw folder into the
                                            InputFile collection
                               Output: None
                               On Failure: Raise Exception

                                Written By: iNeuron Intelligence
                               Version: 1.0
                               Revisions: None

        """

        conn = self.dataBaseConnection()
        db = conn.get_database('wafer_train')
        table = db.InputFile
        db.InputFile.delete_many({}) # Deleting the previous training data to avoid duplication
        goodFilePath = self.goodFilePath
        badFilePath = self.badFilePath
        db = conn.get_database('Training_Logs')
        log_table = db.DbInsertLog
        for f in listdir(goodFilePath):
            try:

                csv = pd.read_csv(goodFilePath+'/' + f) # reading csv file
                data_dict = csv.to_dict("records") # converting to dictionary format to insert in to collection
                table.insert_many(data_dict) # insert into collection/table
                self.logger.log(log_table, " %s: File loaded successfully!!" % f)

            except Exception as e:
                self.logger.log(log_table, "Error while inserting file: %s " % e)
                shutil.move(goodFilePath + '/' + f, badFilePath)
                self.logger.log(log_table, "File Moved Successfully %s" % f)
                raise e

    def selectingDatafromtableintocsv(self):

        """
               Method Name: selectingDatafromtableintocsv
               Description: This method exports the data in InputFile table as a CSV file in a given location.

               Output: None
               On Failure: Raise Exception

                Written By: iNeuron Intelligence
               Version: 1.0
               Revisions: None

        """
        conn = self.dataBaseConnection()
        db = conn.get_database('wafer_train')
        table = db.InputFile
        ls = []
        for rec in table.find(): # finding records one by one and appending to a list
            ls.append(rec)
        self.df = pd.DataFrame(ls) #converting list in to dataframe
        df1=self.df.drop('_id', axis=1) # dropping the first column( objecctID)
        df1.rename(columns={'Good/Bad': 'Output'}, inplace=True) # renaming Good/Bad column as Output


        self.fileFromDb = 'Training_FileFromDB/'
        self.fileName = 'InputFile.csv'
        db = conn.get_database('Training_Logs')
        log_table = db.ExportToCsv

        try:
            #Make the CSV ouput directory
            if not os.path.isdir(self.fileFromDb):
                os.makedirs(self.fileFromDb)

            # Writing to csv file.
            df1.to_csv(self.fileFromDb + self.fileName, index=False)
            self.logger.log(log_table, "File exported successfully!!!")

        except Exception as e:
            self.logger.log(log_table, "File exporting failed. Error : %s" %e)






