from os import listdir
import os
import re
import json
import shutil
from application_logging.logger import App_Logger
from DataTypeValidation_Insertion_Training.DataTypeValidation import dBOperation
from bson.objectid import ObjectId
import boto3
from io import StringIO
import pandas as pd
import smtplib




class Raw_Data_validation:

    """
             This class shall be used for handling all the validation done on the Raw Training Data!!.

             Written By: iNeuron Intelligence
             Version: 1.0
             Revisions: None

             """

    def __init__(self,path):
        self.Batch_Directory = path # s3 bucket
        self.client = boto3.client('s3')
        self.logger = App_Logger()
        self.dBOperation = dBOperation()
        self.df=pd.DataFrame()
        self.bucket_name = 'wafer-train'


    def valuesFromSchema(self):
        """
                Method Name: valuesFromSchema
                Description: This method extracts all the relevant information from the pre-defined "Schema" file
                                stored in train_schema collection.
                Output: LengthOfDateStampInFile, LengthOfTimeStampInFile, column_names, Number of Columns
                On Failure: Raise ValueError,KeyError,Exception

                Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                                """
        try:
            conn=self.dBOperation.dataBaseConnection()
            db = conn['wafer_train']
            table = db["train_schema"]

            result = table.find_one({'_id': ObjectId("6020e2dec485cd71dbd88629")}) # reading schema from table
            pattern = result['SampleFileName']
            LengthOfDateStampInFile = result['LengthOfDateStampInFile']
            LengthOfTimeStampInFile = result['LengthOfTimeStampInFile']
            column_names = result['ColName']
            NumberofColumns = result['NumberofColumns']

            db = conn.get_database('Training_Logs')
            log_table = db.valuesfromSchemaValidationLog
            message = "LengthOfDateStampInFile:: %s" % LengthOfDateStampInFile + " LengthOfTimeStampInFile:: %s" % LengthOfTimeStampInFile + " NumberofColumns:: %s" % NumberofColumns
            self.logger.log(log_table, message)

        except ValueError:
            self.logger.log(log_table, "ValueError:Value not found inside schema_training.json")
            raise ValueError

        except KeyError:
            self.logger.log(log_table, "KeyError:Key value error incorrect key passed")
            raise KeyError

        except Exception as e:
            self.logger.log(log_table, str(e))
            raise e

        return LengthOfDateStampInFile, LengthOfTimeStampInFile, column_names, NumberofColumns


    def manualRegexCreation(self):
        """
                Method Name: manualRegexCreation
                Description: This method contains a manually defined regex based on the "FileName" given in "Schema" file.
                             This Regex is used to validate the filename of the training data.
                Output: Regex pattern
                On Failure: None

                Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                                        """
        regex = "['wafer']+['\_'']+[\d_]+[\d]+\.csv"
        return regex

    def createDirectoryForGoodBadRawData(self):

        """
                  Method Name: createDirectoryForGoodBadRawData
                  Description: This method creates directories to store the Good Data and Bad Data
                                after validating the training data.

                  Output: None
                  On Failure: OSError

                  Written By: iNeuron Intelligence
                  Version: 1.0
                  Revisions: None

                                              """

        try:
            path = os.path.join("Training_Raw_files_validated/", "Good_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)
            path = os.path.join("Training_Raw_files_validated/", "Bad_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)

        except OSError as ex:
            conn = self.dBOperation.dataBaseConnection()
            db = conn.get_database('Training_Logs')
            log_table= db.GeneralLog
            self.logger.log(log_table,"Error while creating Directory %s:" % ex)
            raise OSError



    def deleteExistingGoodDataTrainingFolder(self):

        """
                Method Name: deleteExistingGoodDataTrainingFolder
                Description: This method deletes the directory made  to store the Good Data
                              after loading the data in the table. Once the good files are
                              loaded in the DB,deleting the directory ensures space optimization.
                Output: None
                On Failure: OSError

                Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                                                    """

        try:
            path = 'Training_Raw_files_validated/'
            if os.path.isdir(path + 'Good_Raw/'):
                shutil.rmtree(path + 'Good_Raw/')
                conn = self.dBOperation.dataBaseConnection()
                db = conn.get_database('Training_Logs')
                log_table = db.GeneralLog
                self.logger.log(log_table,"GoodRaw directory deleted successfully!!!")

        except OSError as s:
            self.logger.log(log_table,"Error while Deleting Directory : %s" %s)
            raise OSError

    def deleteExistingBadDataTrainingFolder(self):

        """
                Method Name: deleteExistingBadDataTrainingFolder
                Description: This method deletes the directory made to store the bad Data.
                Output: None
                On Failure: OSError

                Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                                                    """

        try:
            path = 'Training_Raw_files_validated/'
            if os.path.isdir(path + 'Bad_Raw/'):
                shutil.rmtree(path + 'Bad_Raw/')
                conn = self.dBOperation.dataBaseConnection()
                db = conn.get_database('Training_Logs')
                log_table = db.GeneralLog
                self.logger.log(log_table,"BadRaw directory deleted before starting validation!!!")

        except OSError as s:
            self.logger.log(log_table,"Error while Deleting Directory : %s" %s)
            raise OSError

    def moveBadFilesToArchiveBad(self):

        """
                Method Name: moveBadFilesToArchiveBad
                Description: This method deletes the directory made  to store the Bad Data
                              after moving the data in an archive folder in aws s3 bucket
                              and send email notification to the client. We archive the bad
                              files to send them back to the client for invalid data issue.
                Output: None
                On Failure: OSError

                Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                        """

        s3_client = boto3.client('s3') # access to aws s3
        sender_email = 'hfortesting147@gmail.com' # sender_email
        rec_email = 'hfortesting147@gmail.com'  # client email
        password = 'test@12345&'
        server = smtplib.SMTP('smtp.gmail.com', 587) #connecting to gmail server
        server.starttls() # starting server
        server.login(sender_email, password) # login in to the account

        try:

            source = 'Training_Raw_files_validated/Bad_Raw/'
            files = os.listdir(source)
            for f in files:
                s3_client.upload_file(source + f, 'training-archive-bad-data', f) # uplod each file to s3 bucket training-archive-bad-data

                server.sendmail(sender_email, rec_email,
                            'Training file ' + f + ' moved to training-archive-bad-data folder')

            conn = self.dBOperation.dataBaseConnection()
            db = conn.get_database('Training_Logs')
            log_table = db.GeneralLog
            self.logger.log(log_table,"Bad files moved to archive and sent mail notification to client")
            path = 'Training_Raw_files_validated/'
            if os.path.isdir(path + 'Bad_Raw/'):
                shutil.rmtree(path + 'Bad_Raw/')
            self.logger.log(log_table,"Bad Raw Data Folder Deleted successfully!!")
        except Exception as e:
            self.logger.log(log_table, "Error while moving bad files to archive:: %s" % e)
            raise e

    def validationFileNameRaw(self,regex,LengthOfDateStampInFile,LengthOfTimeStampInFile):
        """
                Method Name: validationFileNameRaw
                Description: This function validates the name of the training csv files as per given name in the schema!
                             Regex pattern is used to do the validation.If name format do not match the file is moved
                             to Bad Raw Data folder else in Good raw data.
                Output: None
                On Failure: Exception

                 Written By: iNeuron Intelligence
                Version: 1.0
                Revisions: None

                """
        self.deleteExistingBadDataTrainingFolder()
        self.deleteExistingGoodDataTrainingFolder()
        self.createDirectoryForGoodBadRawData()
        conn = self.dBOperation.dataBaseConnection()
        db = conn.get_database('Training_Logs')
        log_table = db.nameValidationLog

        onlyfiles = [obj.key for obj in self.Batch_Directory.objects.all()]

        try:
            for filename in onlyfiles:
                csv_obj = self.client.get_object(Bucket=self.bucket_name, Key=filename)
                body = csv_obj['Body']
                csv_string = body.read().decode('utf-8') # accessing file conteny
                self.df = pd.read_csv(StringIO(csv_string)) #reading csv in to data frame

                if (re.match(regex, filename)):
                    splitAtDot = re.split('.csv', filename)
                    splitAtDot = (re.split('_', splitAtDot[0]))
                    if len(splitAtDot[1]) == LengthOfDateStampInFile:
                        if len(splitAtDot[2]) == LengthOfTimeStampInFile:
                            self.df.to_csv("Training_Raw_files_validated/Good_Raw/" + filename, index=None, header=True)
                            self.logger.log(log_table, "Valid File name!! File moved to GoodRaw Folder :: %s" % filename)

                        else:
                            self.df.to_csv("Training_Raw_files_validated/Bad_Raw/" + filename, index=None, header=True)
                            self.logger.log(log_table,"Invalid File Name!! File moved to Bad Raw Folder :: %s" % filename)
                    else:
                        self.df.to_csv("Training_Raw_files_validated/Bad_Raw/" + filename, index=None, header=True)
                        self.logger.log(log_table, "Invalid File Name!! File moved to Bad Raw Folder :: %s" % filename)
                else:
                    self.df.to_csv("Training_Raw_files_validated/Bad_Raw/" + filename, index=None, header=True)
                    self.logger.log(log_table, "Invalid File Name!! File moved to Bad Raw Folder :: %s" % filename)

        except Exception as e:
            self.logger.log(log_table, "Error occured while validating FileName %s" % e)
            raise e




    def validateColumnLength(self,NumberofColumns):
        """
                  Method Name: validateColumnLength
                  Description: This function validates the number of columns in the csv files.
                               It is should be same as given in the schema file.
                               If not same file is not suitable for processing and thus is moved to Bad Raw Data folder.
                               If the column number matches, file is kept in Good Raw Data for processing.
                              The csv file is missing the first column name, this function changes the missing name to "Wafer".
                  Output: None
                  On Failure: Exception

                   Written By: iNeuron Intelligence
                  Version: 1.0
                  Revisions: None

              """
        try:
            conn = self.dBOperation.dataBaseConnection()
            db = conn.get_database('Training_Logs')
            log_table = db.columnValidationLog
            self.logger.log(log_table,"Column Length Validation Started!!")

            for f in listdir('Training_Raw_files_validated/Good_Raw/'):
                csv = pd.read_csv("Training_Raw_files_validated/Good_Raw/" + f)
                if csv.shape[1] == NumberofColumns:
                    pass
                else:
                    shutil.move("Training_Raw_files_validated/Good_Raw/" + f, "Training_Raw_files_validated/Bad_Raw")
                    self.logger.log(log_table, "Invalid Column Length for the file!! File moved to Bad Raw Folder")
            self.logger.log(log_table, "Column Length Validation Completed!!")
        except OSError:
            self.logger.log(log_table, "Error Occured while moving the file :: %s" % OSError)
            raise OSError
        except Exception as e:
            self.logger.log(log_table, "Error Occured:: %s" % e)
            raise e


    def validateMissingValuesInWholeColumn(self):
        """
                  Method Name: validateMissingValuesInWholeColumn
                  Description: This function validates if any column in the csv file has all values missing.
                               If all the values are missing, the file is not suitable for processing.
                               SUch files are moved to bad raw data.
                  Output: None
                  On Failure: Exception

                   Written By: iNeuron Intelligence
                  Version: 1.0
                  Revisions: None

                              """
        try:
            conn = self.dBOperation.dataBaseConnection()
            db = conn.get_database('Training_Logs')
            log_table = db.missingValuesInColumn
            self.logger.log(log_table,"Missing Values Validation Started!!")

            for f in listdir('Training_Raw_files_validated/Good_Raw/'):
                csv = pd.read_csv("Training_Raw_files_validated/Good_Raw/" + f)
                count = 0
                for columns in csv:
                    if (len(csv[columns]) - csv[columns].count()) == len(csv[columns]):
                        count+=1
                        shutil.move("Training_Raw_files_validated/Good_Raw/" + f,
                                    "Training_Raw_files_validated/Bad_Raw")
                        self.logger.log(log_table,"Invalid Column Length for the file!! File moved to Bad Raw Folder :: %s" % f)
                        break
                if count==0:
                    csv.rename(columns={"Unnamed: 0": "Wafer"}, inplace=True)
                    csv.to_csv("Training_Raw_files_validated/Good_Raw/" + f, index=None, header=True)
        except OSError:
            self.logger.log(log_table, "Error Occured while moving the file :: %s" % OSError)
            raise OSError
        except Exception as e:
            self.logger.log(log_table, "Error Occured:: %s" % e)
            raise e






